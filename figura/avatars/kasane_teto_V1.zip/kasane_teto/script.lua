local squapi = require("SquAPI")
local swingPirate = require("swingpirate")

vanilla_model.PLAYER:setVisible(false)

local selected_model = config:load("outfit") and models.synthv or models.model

local armourShow = not config:load("armour")

local skirt_FR = selected_model.Root.Body.Skirt.front_right
local skirt_FL = selected_model.Root.Body.Skirt.front_left
local skirt_FC = selected_model.Root.Body.Skirt.front_center
local skirt_BR = selected_model.Root.Body.Skirt.rear_right
local skirt_BL = selected_model.Root.Body.Skirt.rear_left
local skirt_BC = selected_model.Root.Body.Skirt.rear_center

local skirt_L = selected_model.Root.Body.Skirt.l_side
local skirt_R = selected_model.Root.Body.Skirt.r_side

local SKIRT_DEFAULT = 20

local rightLegRot = 0
local leftLegRot = 0

--squapi objects

squapi.eye(
	models.model.Root.Head.Eyes.LEye, --element
	nil, --(.25)leftdistance
	nil, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)

squapi.eye(
	models.model.Root.Head.Eyes.REye, --element
	1.25, --(.25)leftdistance
	0.25, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)

squapi.blink(
	animations.model.Blink, --animation
	1  --(1)chancemultiplier
)

squapi.eye(
	models.synthv.Root.Head.Eyes.LEye, --element
	nil, --(.25)leftdistance
	nil, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)

squapi.eye(
	models.synthv.Root.Head.Eyes.REye, --element
	1.25, --(.25)leftdistance
	0.25, --(1.25)rightdistance
	nil, --(.5)updistance
	nil, --(.5)downdistance
	nil  --(false)switchvalues
)

squapi.blink(
	animations.synthv.Blink, --animation
	1  --(1)chancemultiplier
)

-- swingpirate objects

hair = swingPirate.SwingPhysics(models.model.Root.Head.HairR, nil, {90, -90, 90, -90, 50, -15}, {
			resistance = 0.9,
			weight = 1,
			bounce = 0
		})

hair2 = swingPirate.SwingPhysics(models.model.Root.Head.HairL, nil, {90, -90, 90, -90, 15, -50}, {
			resistance = 0.9,
			weight = 1,
			bounce = 0
		})

hairfront = swingPirate.SwingPhysics(models.model.Root.Head.HairFront, nil, {10, -2, 90, -90, 10, -10}, {
			resistance = 0.9,
			weight = 1.2,
			bounce = 0
		})
		
hairV = swingPirate.SwingPhysics(models.synthv.Root.Head.HairR, nil, {90, -90, 90, -90, 50, -15}, {
			resistance = 0.9,
			weight = 1,
			bounce = 0
		})

hairV2 = swingPirate.SwingPhysics(models.synthv.Root.Head.HairL, nil, {90, -90, 90, -90, 15, -50}, {
			resistance = 0.9,
			weight = 1,
			bounce = 0
		})

hairVfront = swingPirate.SwingPhysics(models.synthv.Root.Head.HairFront, nil, {10, -2, 90, -90, 10, -10}, {
			resistance = 0.9,
			weight = 1.2,
			bounce = 0
		})

selected_model.Skull:setVisible(true)
selected_model.Portrait:setVisible(true)

if selected_model == models.model then
	models.synthv:setVisible(false)
	hairV:setEnabled(false)
	hairV2:setEnabled(false)
	hairVfront:setEnabled(false)
else
	
	models.model:setVisible(false)
	hair:setEnabled(false)
	hair2:setEnabled(false)
	hairfront:setEnabled(false)
end

local mainPage = action_wheel:newPage()
action_wheel:setPage(mainPage)

function pings.hidea(state)
	config:save("armour", state)
	armourShow = not state
	vanilla_model.ARMOR:setVisible(not state)
end

pings.hidea(not armourShow)
	
local action_hidea = mainPage:newAction()
    :title("Hide Armour")
    :toggleTitle("Unhide Armour")
    :item("minecraft:iron_chestplate")
    :toggleItem("minecraft:chainmail_chestplate")
    :setOnToggle(pings.hidea)

function pings.swap_outfit(state)
	if selected_model ~= (state and models.synthv or models.model) then
		config:save("outfit", state)
	
		selected_model = state and models.synthv or models.model

		selected_model.Skull:setVisible(true)
		selected_model.Portrait:setVisible(true)

		if selected_model == models.model then
			models.synthv:setVisible(false)
			models.model:setVisible(true)
			
			models.model.Skull:setVisible(true)
			models.model.Portrait:setVisible(true)
			models.synthv.Skull:setVisible(false)
			models.synthv.Portrait:setVisible(false)
			
			hairV:setEnabled(false)
			hairV2:setEnabled(false)
			hairVfront:setEnabled(false)
			hair:setEnabled(true)
			hair2:setEnabled(true)
			hairfront:setEnabled(true)
		else
			models.model:setVisible(false)
			models.synthv:setVisible(true)
			
			models.synthv.Skull:setVisible(true)
			models.synthv.Portrait:setVisible(true)
			models.model.Skull:setVisible(false)
			models.model.Portrait:setVisible(false)
			
			hairV:setEnabled(true)
			hairV2:setEnabled(true)
			hairVfront:setEnabled(true)
			hair:setEnabled(false)
			hair2:setEnabled(false)
			hairfront:setEnabled(false)
		end

		skirt_FR = selected_model.Root.Body.Skirt.front_right
		skirt_FL = selected_model.Root.Body.Skirt.front_left
		skirt_FC = selected_model.Root.Body.Skirt.front_center
		skirt_BR = selected_model.Root.Body.Skirt.rear_right
		skirt_BL = selected_model.Root.Body.Skirt.rear_left
		skirt_BC = selected_model.Root.Body.Skirt.rear_center

		skirt_L = selected_model.Root.Body.Skirt.l_side
		skirt_R = selected_model.Root.Body.Skirt.r_side	
	end
end
	
local action_outfit = mainPage:newAction()
    :title("Switch to SynthV")
    :toggleTitle("Switch to Vocaloid")
    :item("minecraft:white_wool")
    :toggleItem("minecraft:gray_wool")
	:setToggleColor(0,0,0)
    :setOnToggle(pings.swap_outfit)
	
function pings.name_override(state)
	--yoinked code from riftlight

	config:save("name_override", state)

	local text = state and "Kasane Teto" or avatar:getEntityName()
	local pText = {}
	for char in text:gmatch("[\x00-\x7F\xC2-\xF4][\x80-\xBF]*") do
	  table.insert(pText, char)
	end
	local color1 = vec(234/256, 91/256, 108/256) -- replace these with whatever rgbs you want
	local color2 = vec(135/256, 16/256, 67/256)
	local json = {}
	for i, c in ipairs(pText) do
	  table.insert(json, {
		text = c,
		color = "#" .. vectors.rgbToHex(math.lerp(color1, color2, (i - 1) / #pText)),
	  })
	end
	
	nameplate.ALL:setText(toJson(json))
end
	
local action_name = mainPage:newAction()
    :title("Override Name\nName will show as: \"Kasane Teto\"")
    :toggleTitle("Default Name")
    :item("minecraft:iron_block")
    :toggleItem("minecraft:grass_block")
	:setToggleColor(0,0,0)
    :setOnToggle(pings.name_override)

--init pings

pings.hidea(not armourShow)
pings.swap_outfit(config:load("outfit"))
pings.name_override(config:load("name_override"))

action_hidea:setToggled(not armourShow)
action_outfit:setToggled(config:load("outfit"))
action_name:setToggled(config:load("name_override"))


function events.tick(delta)	

	if selected_model == models.model then
		swingPirate.AnchorHead(hair)
		swingPirate.AnchorHead(hair2)
		swingPirate.AnchorHead(hairfront, nil, nil, nil, nil, 10, -2)
	else
		swingPirate.AnchorHead(hairV)
		swingPirate.AnchorHead(hairV2)
		swingPirate.AnchorHead(hairVfront, nil, nil, nil, nil, 10, -2)

	end

	if player:isLoaded() then
		if player:getItem(4).id == "minecraft:air" or not armourShow then
			
			selected_model.Root.Body.Skirt:setRot(-vanilla_model.BODY:getOriginRot().x,0,0)
			if player:getPose() == "CROUCHING" then
				selected_model.Root.Body.Skirt:setPos(0,1.4,-1)
			elseif player:getPose() == "SITTING" then
				selected_model.Root.Body.Skirt:setPos(0,0,0)
			else
				selected_model.Root.Body.Skirt:setPos(0,0,0)
			end
			
			selected_model.Root.Body.Skirt:setVisible(true)
			selected_model.Root.LeftLeg.belt:setVisible(true)
		else
			selected_model.Root.Body.Skirt:setVisible(false)
			selected_model.Root.LeftLeg.belt:setVisible(false)
		end
		
		if player:getItem(6).id == "minecraft:air" or not armourShow then
			selected_model.Root.Head.top_hair:setVisible(true)
		else
			selected_model.Root.Head.top_hair:setVisible(false)
		end
	end
	
	-- ping for late loaders
	if world:getTime() % 600 == 0 then
		pings.hidea(not armourShow)
		pings.swap_outfit(selected_model == models.synthv)
		pings.name_override(config:load("name_override") or false)
	end
end

function events.render(delta)
	if selected_model.Root.Body.Skirt:getVisible() then
		--skirt
		local rightLegRot = vanilla_model.RIGHT_LEG:getOriginRot().x
		local leftLegRot = vanilla_model.LEFT_LEG:getOriginRot().x

		local fr_rot = math.max(rightLegRot+10, SKIRT_DEFAULT)
		local fl_rot = math.max(leftLegRot+10, SKIRT_DEFAULT)
		local fc_rot = (fl_rot+fr_rot)/2
		
		local br_rot = math.min(rightLegRot-10, -SKIRT_DEFAULT)
		local bl_rot = math.min(leftLegRot-10, -SKIRT_DEFAULT)
		local bc_rot = (bl_rot+br_rot)/2
		
		skirt_FR:setRot(fr_rot,0, 0)
		skirt_FL:setRot(fl_rot,0, 0)
		skirt_FC:setRot(fc_rot,0, 0)
		skirt_FC.cube:setRot(0, fr_rot-fl_rot, 0)
		
		
		skirt_L.FrontL:setRot(0,math.max(leftLegRot, 0),0)
		skirt_L.RearL:setRot(0,math.min(leftLegRot, 0),0)
		
		if player:getVehicle() then
			skirt_L:setRot(15,10, -30)
			skirt_L:setPos(0,1,0)
			skirt_R:setRot(15,-10, 30)
			skirt_R:setPos(0,1,0)
		else
			skirt_L:setRot(0,0,math.min(-20+math.abs(leftLegRot/5), -5))
			skirt_L:setPos(0,0,0)
			skirt_R:setRot(0,0, math.max(20-math.abs(rightLegRot/5), 5))
			skirt_R:setPos(0,0,0)
		end
		
		skirt_R.FrontR:setRot(0,math.min(-rightLegRot, 0),0)
		skirt_R.RearR:setRot(0,math.max(-rightLegRot, 0),0)
		
		skirt_BR:setRot(br_rot,0, 0)
		skirt_BL:setRot(bl_rot,0, 0)
		skirt_BC:setRot(bc_rot,0, 0)
		skirt_BC.cube:setRot(0,br_rot-bl_rot, 0)
	end
end