# Changelog

### v1.3.0 - REI and Traveler's Backpack - 2024-06-05

Added support for [REI](https://modrinth.com/mod/rei) and [Traveler's Backpack](https://modrinth.com/mod/travelersbackpack) mods and updated [Curios API](https://modrinth.com/mod/curios) textures.

**Additions:**
- Support for [Roughly Enough Items (REI)](https://modrinth.com/mod/rei) and [Traveler's Backpack](https://modrinth.com/mod/travelersbackpack) mods.

**Changes**
- Updated [Curios API](https://modrinth.com/mod/curios) support to have a inventory revamp texture.

### v1.2.0 - Inmis and Inventorio - 2024-04-19

Added support for [Inmis](https://modrinth.com/mod/inmis) and [Inventorio](https://modrinth.com/mod/inventorio) mods.

**Additions:**
- Support for [Inmis](https://modrinth.com/mod/inmis) and [Inventorio](https://modrinth.com/mod/inventorio) mods by `@533k` (Seek) on Discord.

### v1.1.0 - More Mods - 2024-04-12

Added support for [Expanded Storage](https://modrinth.com/mod/expanded-storage), [Trinkets](https://modrinth.com/mod/trinkets) and [Iron Furnaces](https://modrinth.com/mod/iron-furnaces) mods.

**Changes**
- Changed vanilla inventory texture to have space for slots added by mods.

**Additions:**
- Support for [Expanded Storage](https://modrinth.com/mod/expanded-storage) and [Trinkets](https://modrinth.com/mod/trinkets) mod;
- Support for [Iron Furnaces](https://modrinth.com/mod/iron-furnaces) mod by `@torchthedragon` on Discord.


### v1.0.0 - Release

Create support and some fixes.

**Additions:**
- Support for [Create](https://modrinth.com/mod/create) and [Create Fabric](https://modrinth.com/mod/create-fabric) mods. By: `@torchthedragon` on Discord.

**Fixes**
- Waystones mod checkbox;
- Tom's Simple Storage mod terminals;
- Sophisticated Core mod gui controls.