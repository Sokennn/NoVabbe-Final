Soken edit texture contiene:
- CavsCobbleMons
- ZacianZama
- Diancie
- Keldeo
- Cobblemon Battle Music